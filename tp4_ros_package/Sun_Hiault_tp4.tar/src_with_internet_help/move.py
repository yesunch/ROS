class Move:
    def __init__(self, length, dtheta):
        self.length = length
        self.dtheta = dtheta
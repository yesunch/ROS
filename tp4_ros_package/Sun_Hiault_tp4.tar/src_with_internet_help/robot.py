class Robot:
    def __init__(self, width = 2.0, height = 3.0):
        self.width = width
        self.height = height